Project 2: Rotations Part 3
Made by:
Zhida Chen
Adrià Sellarés

IMPORTANT:
To execute the Julia code you must install the following packages:

Quaternions
ReferenceFrameRotations

You can use these:

import Pkg; Pkg.add("Quaternions")

import Pkg; Pkg.add("ReferenceFrameRotations")
