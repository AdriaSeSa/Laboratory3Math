Project 3: Affine
Made by:
Zhida Chen
Adrià Sellarés

The project is divided in three folders. 
Exercice_3_Julia and Exercice_4_Julia contain the Julia program 
Exercice_1_2_4 contains the hand-made problems solved.

IMPORTANT:
To execute the Julia code you must install the following packages:

Quaternions
ReferenceFrameRotations

You can use these:

import Pkg; Pkg.add("Quaternions")

import Pkg; Pkg.add("ReferenceFrameRotations")